/*!
 * Concomsis JMY
 * Copyright(c) 2009-2019 Juan Manuel Martinez Garcias
 * MIT Licensed
 */
'use strict';

/**
 * Module dependencies.
 */


/**
 * Module exports.
 * @public
 */
exports.key = {
    servidor:"https://comsis.mx/api/auth/v1/",
    path:"holamundo-a0c04/us-central1/api/",
    localhost:true,
    localhost_api:"https://us-central1-encouraging-mix-111109.cloudfunctions.net/da/",
    api_server:"e2ad454bea7d919f0fc411a8b885580c", 
    api:"c5594c6085437d206ab73b4c2ace3596",
    apikey:"ff9ff56d008e7fb8ef5ce5bdeab84814",
  };

/**
 * Module variables.
 * @private
 */
